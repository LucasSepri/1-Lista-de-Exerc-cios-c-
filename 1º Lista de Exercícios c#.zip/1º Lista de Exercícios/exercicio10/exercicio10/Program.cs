﻿using System;

namespace exercicio10
{
    class Program
    {
        static void Main(string[] args)
        {
            int W;
            int X;
            int Y;
            int Z;
        
            Console.WriteLine("Digite o valor de W : ");
            W = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de X : ");
            X = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de Y : ");
            Y = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de Z : ");
            Z = int.Parse(Console.ReadLine());


            if (((X >= Y) && (Z <= X)) || ((X == W) && (Y == Z)) || (!(X != W)))
            {
                Console.WriteLine("é verdade");
            } else
                {
                Console.WriteLine("é mentira");
                }

            Console.ReadKey();







        }
    }
}
