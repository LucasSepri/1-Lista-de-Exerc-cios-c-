﻿using System;

namespace exercicio4
{
    class Program
    {
        static void Main(string[] args)
        {

            Double A;
            Double B;
            Double C;
            Double Resultado;

            Console.WriteLine("Digite o valor de A");
            A = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de B");
            B = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de C");
            C = Double.Parse(Console.ReadLine());

            Resultado = (A * A* 5 - C) / (B - A % 4);

            Console.WriteLine("O resultado da expressão é : " + Resultado);
            Console.ReadKey();

        }
    }
}
