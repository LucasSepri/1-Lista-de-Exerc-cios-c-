﻿using System;

namespace exercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            int idade;
            Console.WriteLine("Digite sua idade ");
            idade = int.Parse(Console.ReadLine());

            if (idade >= 0 && idade <= 11)
            {
                Console.WriteLine("Você é uma criança");

            }
            else if (idade >= 12 && idade <= 18)
            {
                Console.WriteLine("Você é um adolescente");

            }
            else if (idade >= 18 && idade <= 60)
            {
                Console.WriteLine("Você é um adulto");
            }
            else
            {
                Console.WriteLine("Você é um idoso");
            }

            Console.ReadKey();


        }
    }
}


