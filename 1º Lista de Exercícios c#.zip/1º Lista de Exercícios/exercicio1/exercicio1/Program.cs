﻿using System;

namespace exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;
            Double idade;
            string cidade;

            idade = 29;
            nome = "João Henrique da Silva Costa";
            cidade = "Mongaguá";

     
            Console.WriteLine("Meu nome é: " + nome);
            Console.WriteLine("Moro em : " + cidade);
            Console.WriteLine("Tenho : "+ idade +" anos ");
            idade = Double.Parse(Console.ReadLine());

        }
    }
}
