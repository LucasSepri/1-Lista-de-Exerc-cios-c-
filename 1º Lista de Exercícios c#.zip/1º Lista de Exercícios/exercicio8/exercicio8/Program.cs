﻿using System;

namespace exercicio8
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Real;
            const Double dolar = 5.23;
            const Double euro = 6.20;
            Double conversao_dolar;
            Double conversao_euro;
            
            Console.WriteLine("Digite o valor para conversão : ");
            Real = Double.Parse(Console.ReadLine());

            conversao_dolar = Real * dolar;
            conversao_euro = Real * euro;

            Console.WriteLine("Seu dinheiro de real para dolar será : " + conversao_dolar);
            Console.WriteLine("Seu dinheiro de real para euro será : " + conversao_euro);
            Console.ReadKey();

        }
    }
}
