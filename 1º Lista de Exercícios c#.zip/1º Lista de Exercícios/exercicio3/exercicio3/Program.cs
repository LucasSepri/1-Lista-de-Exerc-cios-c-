﻿using System;

namespace exercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1;
            Double raiz;
            
            Console.WriteLine("Digite um número: " );
            n1 = int.Parse(Console.ReadLine());

            raiz = Math.Sqrt(n1);
            Console.WriteLine("A raiz quadra desse número é " + raiz);
            raiz = Double.Parse(Console.ReadLine());

            Console.ReadKey();


        }
    }
}
