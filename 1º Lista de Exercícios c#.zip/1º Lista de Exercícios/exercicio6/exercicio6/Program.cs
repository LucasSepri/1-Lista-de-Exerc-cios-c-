﻿using System;

namespace exercicio6
{
    class Program
    {
        static void Main(string[] args)
        {

            Double Real;
            const Double dolar = 5.23;
            Double Conversão;
            
            Console.WriteLine("Digite o valor em dolar para a conversão " );
            Real = Double.Parse(Console.ReadLine());
            Conversão = Real * dolar;
            Console.WriteLine("Seu dinheiro em Real será : " + Conversão);
            Console.ReadKey();
            
        }
    }
}
