﻿using System;

namespace exercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1;
            n1 = 20;

            Console.WriteLine("valor de n1: " + n1);
            n1 = n1+n1;
            Console.WriteLine("O dobro de n1: " + n1);
            n1 = int.Parse(Console.ReadLine());



        }
    }
}
