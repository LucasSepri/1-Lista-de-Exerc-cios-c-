﻿using System;

namespace exercicio7
{
    class Program
    {
        static void Main(string[] args)
        {
            string Nome3 = "João Henrique da Silva Costa";
            string Nome4 = "Fabio Vinius Santos de Freitas";

            Console.WriteLine("Primeiro nome: "+Nome3);
            Console.WriteLine("Segundo nome: "+Nome4);



            string Nome = "João Henrique da Silva Costa";
            int tamanho = Nome.Length;
            string Nome2 = "Fabio Vinius Santos de Freitas";
            int tamanho2 = Nome2.Length;

            Console.WriteLine("Esse nome possui : "  + tamanho +  " caracteres" );
            Console.WriteLine("O segundo nome possui : " + tamanho2 +  " caracteres" );

            string Nome5 = "Joã";
            int tamanho5 = Nome.Length;
            string Nome6 = "Fab";
            int tamanho6 = Nome2.Length;

            Console.WriteLine("Os três primeiros caracteres desse nome são : "+Nome5);
            Console.WriteLine("Os três primeiros caracteres desse nome são : " + Nome6);



            Console.ReadKey();
        }
    }
}
